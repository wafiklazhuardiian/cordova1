<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id12789255_akademik","123456789","id12789255_akademik") or die ("could not connect database");
?>