<?php
 include "db.php";
 if(isset($_POST['insert']))
 {
 $no=$_POST['no'];
 $tipe_kamera=$_POST['tipe_kamera'];
 $tambahan=$_POST['tambahan'];
 $sewa=$_POST['sewa'];
 $q=mysqli_query($con,"INSERT INTO `kamera` (`no`,`tipe_kamera`,`tambahan,`sewa`) VALUES ('$no','$tipe_kamera','$tambahan','$sewa')");
 if($q)
  echo "success";
 else
  echo "error";
 }
 ?>