<?php
 include "db.php";
 if(isset($_POST['update']))
 {
 $no=$_POST['no'];
 $tipe_kamera=$_POST['tipe_kamera'];
 $tambaha=$_POST['tambahan'];
 $sewa=$_POST['sewa'];
 $q=mysqli_query($con,"UPDATE `kamera` SET `no`='$no',`tipe_kamera`='$tipe_kamera',`tambahan`='$tambahan', `sewa`='$sewa' where `no`='$no'");
 if($q)
 echo "success";
 else
 echo "error";
 }
 ?>